<?php
/**
 * Database Configuration File
 * Beauty Website - College Project
 */

// ============================================
// INFINITYFREE SETTINGS - Fill your details below
// ============================================
$host = "FILL_YOUR_HOST";           // Example: sql123.infinityfree.com
$username = "FILL_YOUR_USERNAME";   // Example: if0_12345678
$password = "FILL_YOUR_PASSWORD";   // Your database password
$database = "FILL_YOUR_DATABASE";   // Example: if0_12345678_beauty

// ============================================
// DATABASE CONNECTION (Don't change below)
// ============================================

// Create connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    // Show user-friendly error on live site
    die("<div style='text-align:center; padding:50px; font-family:Arial;'>
            <h2 style='color:#d81b60;'>Database Connection Error</h2>
            <p>Unable to connect to database. Please check your configuration.</p>
         </div>");
}

// Set charset to handle special characters
mysqli_set_charset($conn, "utf8");
?>
